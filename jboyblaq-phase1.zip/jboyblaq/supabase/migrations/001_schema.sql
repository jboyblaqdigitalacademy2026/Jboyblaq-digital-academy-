-- JboyBlaq Digital Academy: Phase 1 schema. Run once in Supabase SQL Editor.
create extension if not exists pgcrypto;

create type user_role      as enum ('student','admin');
create type course_status  as enum ('draft','published');
create type payment_method as enum ('zenith_transfer','paystack');
create type payment_status as enum ('pending','verified','rejected');

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  email text not null,
  role user_role not null default 'student',
  created_at timestamptz not null default now()
);

-- completion_percent = configurable certificate requirement
create table courses (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null unique,
  description text not null default '',
  price_ngn numeric(12,2) not null check (price_ngn >= 0),
  thumbnail_url text,
  status course_status not null default 'draft',
  completion_percent int not null default 100 check (completion_percent between 1 and 100),
  created_at timestamptz not null default now()
);

-- video_id = ID at the video host (e.g. Bunny Stream)
create table lessons (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references courses(id) on delete cascade,
  title text not null,
  video_id text,
  position int not null default 0,
  status course_status not null default 'draft',
  created_at timestamptz not null default now()
);
create index on lessons (course_id, position);

-- provider fields prepare for Paystack
create table payments (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references profiles(id) on delete restrict,
  course_id uuid not null references courses(id) on delete restrict,
  amount_ngn numeric(12,2) not null,
  method payment_method not null default 'zenith_transfer',
  provider_reference text unique,
  proof_url text,
  status payment_status not null default 'pending',
  reviewed_by uuid references profiles(id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);
create unique index one_pending_payment  on payments (student_id, course_id) where status = 'pending';
create unique index one_verified_payment on payments (student_id, course_id) where status = 'verified';

create table enrollments (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references profiles(id) on delete cascade,
  course_id uuid not null references courses(id) on delete cascade,
  payment_id uuid not null references payments(id),
  granted_at timestamptz not null default now(),
  unique (student_id, course_id)
);

create table lesson_progress (
  student_id uuid not null references profiles(id) on delete cascade,
  lesson_id uuid not null references lessons(id) on delete cascade,
  completed_at timestamptz not null default now(),
  primary key (student_id, lesson_id)
);

create table certificates (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references profiles(id) on delete cascade,
  course_id uuid not null references courses(id) on delete cascade,
  code text not null unique default upper(substr(encode(gen_random_bytes(6),'hex'),1,10)),
  issued_at timestamptz not null default now(),
  unique (student_id, course_id)
);

create function is_admin() returns boolean language sql stable security definer set search_path = public as
$$ select exists (select 1 from profiles where id = auth.uid() and role = 'admin') $$;

create function has_enrollment(c uuid) returns boolean language sql stable security definer set search_path = public as
$$ select exists (select 1 from enrollments where student_id = auth.uid() and course_id = c) $$;

-- Every public sign-up becomes a student. No exceptions.
create function handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, email, full_name, role)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name',''), 'student');
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

-- Logged-in website users can never change a role. Only the SQL Editor can.
create function protect_role() returns trigger language plpgsql as $$
begin
  if new.role is distinct from old.role and auth.uid() is not null then
    raise exception 'Role cannot be changed from the website';
  end if;
  return new;
end $$;
create trigger lock_role before update on profiles for each row execute function protect_role();

-- Approve a transfer: mark verified and grant access in one atomic step.
create function approve_payment(p_id uuid) returns void language plpgsql security definer set search_path = public as $$
declare p payments;
begin
  if not is_admin() then raise exception 'Admins only'; end if;
  select * into p from payments where id = p_id for update;
  if p.id is null then raise exception 'Payment not found'; end if;
  if p.status <> 'pending' then raise exception 'Payment already %', p.status; end if;
  update payments set status='verified', reviewed_by=auth.uid(), reviewed_at=now() where id = p_id;
  insert into enrollments (student_id, course_id, payment_id)
  values (p.student_id, p.course_id, p.id) on conflict (student_id, course_id) do nothing;
end $$;

create function reject_payment(p_id uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Admins only'; end if;
  update payments set status='rejected', reviewed_by=auth.uid(), reviewed_at=now()
  where id = p_id and status = 'pending';
end $$;

alter table profiles        enable row level security;
alter table courses         enable row level security;
alter table lessons         enable row level security;
alter table payments        enable row level security;
alter table enrollments     enable row level security;
alter table lesson_progress enable row level security;
alter table certificates    enable row level security;

create policy profiles_read   on profiles for select using (id = auth.uid() or is_admin());
create policy profiles_update on profiles for update using (id = auth.uid()) with check (id = auth.uid());

create policy courses_public  on courses for select using (status = 'published' or is_admin());
create policy courses_admin   on courses for all using (is_admin()) with check (is_admin());

create policy lessons_enrolled on lessons for select using (status = 'published' and has_enrollment(course_id));
create policy lessons_admin    on lessons for all using (is_admin()) with check (is_admin());

create policy payments_read   on payments for select using (student_id = auth.uid() or is_admin());
create policy payments_create on payments for insert with check (
  student_id = auth.uid() and status = 'pending' and reviewed_by is null);

create policy enroll_read     on enrollments for select using (student_id = auth.uid() or is_admin());

create policy progress_read   on lesson_progress for select using (student_id = auth.uid() or is_admin());
create policy progress_write  on lesson_progress for insert with check (
  student_id = auth.uid() and exists (
    select 1 from lessons l where l.id = lesson_id and has_enrollment(l.course_id)));

create policy cert_read       on certificates for select using (student_id = auth.uid() or is_admin());
