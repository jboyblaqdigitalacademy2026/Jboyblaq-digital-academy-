# JboyBlaq Digital Academy: Phase 1 (Foundation)

## Setup
1. Install Node.js 18+ (nodejs.org).
2. Create a free project at supabase.com.
3. Supabase > SQL Editor > New query > paste all of `supabase/migrations/001_schema.sql` > Run.
4. Supabase > Project Settings > API: copy the Project URL and anon key.
5. Copy `.env.example` to `.env.local` and fill in the values.
6. In this folder run: `npm install` then `npm run dev`. Open http://localhost:3000

## Make yourself the only admin
1. Register normally at /register with your own email and confirm it.
2. In the SQL Editor run (use your email):
   update profiles set role = 'admin' where email = 'you@example.com';
3. Log in: the dashboard now shows "Open admin area".
There is no admin sign-up page, and the database blocks role changes from the website.

## Phase 1 test checklist
- Register a student, confirm email, log in, see dashboard, log out.
- Visit /admin as student: redirected to /dashboard.
- Visit /dashboard or /admin logged out: redirected to /login.
- Log in as admin: /admin opens.
- Student tries to self-promote: blocked (role trigger).
