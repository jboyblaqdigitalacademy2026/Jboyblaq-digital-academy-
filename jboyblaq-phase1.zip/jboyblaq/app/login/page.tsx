"use client";
import { useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/client";

export default function Login() {
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    setBusy(true);
    const { error } = await supabaseBrowser().auth.signInWithPassword({
      email: String(f.get("email")), password: String(f.get("password")),
    });
    if (error) { setBusy(false); return setError("Incorrect email or password."); }
    window.location.href = "/dashboard";
  }
  return (
    <form className="card" onSubmit={submit}>
      <h2>Log in</h2>
      <label htmlFor="email">Email</label><input id="email" name="email" type="email" required />
      <label htmlFor="password">Password</label><input id="password" name="password" type="password" required />
      <button disabled={busy}>{busy ? "Please wait…" : "Log in"}</button>
      {error && <p className="error">{error}</p>}
      <p>New here? <a href="/register">Create an account</a></p>
    </form>
  );
}
