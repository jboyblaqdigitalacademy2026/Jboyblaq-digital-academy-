"use client";
import { useState } from "react";
import { supabaseBrowser } from "@/lib/supabase/client";

export default function Register() {
  const [msg, setMsg] = useState<{ t: "error" | "ok"; s: string } | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const password = String(f.get("password"));
    if (password.length < 8) return setMsg({ t: "error", s: "Password must be at least 8 characters." });
    setBusy(true);
    // Role is NOT sent. The database forces every new account to "student".
    const { error } = await supabaseBrowser().auth.signUp({
      email: String(f.get("email")),
      password,
      options: { data: { full_name: String(f.get("name")) } },
    });
    setBusy(false);
    setMsg(error ? { t: "error", s: error.message }
      : { t: "ok", s: "Account created. Check your email to confirm, then log in." });
  }
  return (
    <form className="card" onSubmit={submit}>
      <h2>Create your account</h2>
      <label htmlFor="name">Full name</label><input id="name" name="name" required />
      <label htmlFor="email">Email</label><input id="email" name="email" type="email" required />
      <label htmlFor="password">Password</label><input id="password" name="password" type="password" required minLength={8} />
      <button disabled={busy}>{busy ? "Please wait…" : "Register"}</button>
      {msg && <p className={msg.t}>{msg.s}</p>}
      <p>Already registered? <a href="/login">Log in</a></p>
    </form>
  );
}
