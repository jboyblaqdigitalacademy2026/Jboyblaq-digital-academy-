import { requireAdmin } from "@/lib/auth";

export default async function Admin() {
  const { profile } = await requireAdmin();
  return (
    <>
      <h1>Admin</h1>
      <p>Signed in as {profile?.email}. Course, lesson and payment tools arrive in Phases 3 and 4.</p>
    </>
  );
}
