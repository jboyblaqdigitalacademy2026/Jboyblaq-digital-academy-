import "./globals.css";
import Link from "next/link";
import { supabaseServer } from "@/lib/supabase/server";

export const metadata = {
  title: "JboyBlaq Digital Academy",
  description: "Practical digital skills courses.",
};
export const dynamic = "force-dynamic";

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const { data: { user } } = await supabaseServer().auth.getUser();
  return (
    <html lang="en">
      <head><meta name="viewport" content="width=device-width, initial-scale=1" /></head>
      <body>
        <header>
          <Link href="/" className="brand">JboyBlaq Digital Academy</Link>
          <nav>
            {user ? (
              <>
                <Link href="/dashboard">My Courses</Link>
                <form action="/auth/signout" method="post" style={{ display: "inline" }}>
                  <button className="link">Log out</button>
                </form>
              </>
            ) : (<><Link href="/login">Log in</Link><Link href="/register">Register</Link></>)}
          </nav>
        </header>
        <main>{children}</main>
      </body>
    </html>
  );
}
