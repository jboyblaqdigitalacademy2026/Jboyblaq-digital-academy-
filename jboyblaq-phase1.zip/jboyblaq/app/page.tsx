export default function Home() {
  return (
    <>
      <h1>JboyBlaq Digital Academy</h1>
      <p>Homepage and course catalogue arrive in Phase 2.</p>
    </>
  );
}
