import Link from "next/link";
import { requireUser } from "@/lib/auth";

export default async function Dashboard() {
  const { profile } = await requireUser();
  return (
    <>
      <h1>Welcome, {profile?.full_name || "student"}</h1>
      <p>Your purchased courses will appear here (Phase 5).</p>
      {profile?.role === "admin" && <Link className="btn inline" href="/admin">Open admin area</Link>}
    </>
  );
}
